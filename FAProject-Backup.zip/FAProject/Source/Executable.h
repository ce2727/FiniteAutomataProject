#include "SubsetConstruction.h"
//Main executing method
int main();

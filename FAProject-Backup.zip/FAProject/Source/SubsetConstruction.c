#include "SubsetConstruction.h"
/*
*Converts an implementation of a NFA to a DFA. The output DFA accepts the
*same language as an NFA does, therefore accepting on strings the NFA does as well.
*/
DFA* Convert(NFA* nfa)
{
 DFA* converted = initialize_DFA(Math_power(2,nfa->states));//Allocate new DFA with 2^(nfa size) nodes
 int* tracking = (int*)calloc(Math_power(2,nfa->states),sizeof(int));//Keeps track of what nodes have been visited
 LinkedList* stack = LinkedList_new();
 LinkedList_add_at_end(stack,1);//Add first state to the stack

 while(!LinkedList_is_empty(stack))//While there are still nodes on the stack
 {
   int current = LinkedList_pop(stack);

   //Now we create the DFA set holding the possible NFA states
   LinkedSet* DFA_components = LinkedSet_new();
   int iterating_state = current;
   for (int i = 0; i < nfa->states; i++)
   {
     if(iterating_state % 2 != 0)
     {
       LinkedSet_add_at_end(DFA_components,i);
       if (nfa->state_array[i].accepts){
         DFA_set_accepting(converted,current);
       }
       iterating_state = iterating_state >> 1;
     }

     for(int i = 0; i < ASCII_Chars; i++){
       int stateNumber = 0;

      LinkedSetIterator* DFAC_Iter = LinkedSet_iterator(DFA_components);//DFA component states iterator
       while (LinkedSetIterator_has_next(DFAC_Iter)){
         LinkedSetIterator* T_Iter = LinkedSet_iterator(nfa->state_array[LinkedSetIterator_next(DFAC_Iter)].transitions[i]);
         while(LinkedSetIterator_has_next(T_Iter)){
           stateNumber = stateNumber | 1 << LinkedSetIterator_next(T_Iter);
         }
         free(T_Iter);
       }

       if (stateNumber != 0){
         if(tracking[stateNumber] == 0){
           LinkedList_add_at_end(stack, stateNumber);
           tracking[stateNumber] = 1;
           DFA_set_transition(converted,current,i,stateNumber);
         }
         else {
           DFA_set_transition(converted,current,i,stateNumber);
         }
       }
       free(DFAC_Iter);
     }
     LinkedSet_free(DFA_components);
   }
   LinkedList_free(stack);
 }
 return converted;
}

#include <stdlib.h>
#include <stdio.h>
/*
*This file holds any math functions used by the project
*/
//Returns the power of first parameter, to the nth power (x^n)
extern int Math_power(int x, int n);

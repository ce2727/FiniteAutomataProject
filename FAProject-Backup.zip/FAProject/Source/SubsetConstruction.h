#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "Math.h"
#include "NFA.h"
#include "DFA.h"
#include "LinkedList.h"

extern DFA* Convert(NFA* nfa);

/*
Based off of Geroge Furgeson's included LinkedList file
Adopts the functionality of a set, yet unlike his IntSet
system, it allows for pointers of the systems to be made
*/

#include "LinkedList.h"
inline int LinkedList_contains(LinkedList *list, int data) {
  for (LinkedListNode *node=list->first; node != NULL; node=node->next) {
	   if (node->data == data) {
	    return 1;
	}
    }
    return 0;
}

/**
 * Allocate, initialize and return a new (empty) LinkedList.
 */
 //!!ADDED INLINE HERE BECAUSE OF STATIC REMOVE IN .C FILE!!
inline LinkedList* LinkedList_new() {
    LinkedList *list = (LinkedList*)malloc(sizeof(LinkedList));
    list->first = list->last = NULL;
    return list;
}

inline LinkedListNode * LinkedListNode_new(int d) {
    LinkedListNode *node = (LinkedListNode*)malloc(sizeof(LinkedListNode));
    if (node == NULL) {
	abort();
    }
    node->data = d;
    node->next = node->prev = NULL;
    return node;
}

inline void LinkedList_free(LinkedList *list) {
    // Free the elements
    LinkedListNode *elt = list->first;
    while (elt != NULL) {
	LinkedListNode *next = elt->next;
	free(elt);
	elt = next;
    }
    // Free the list itself
    free(list);
}

/**
 * Return true if the given LinkedList is empty.
 */
inline int LinkedList_is_empty(const LinkedList *list) {
    return list->first == NULL;
}

inline int LinkedList_pop(LinkedList* list){
    int data;
    if (list->first->next != NULL) {
      data = list->first->next->data;
      //free(list->first->next);
      list->first->next = list->first->next->next;
      list->first->next->next->prev = list->first;
      return data;
    }
    else
      return -1;
}


inline void LinkedList_add_at_end(LinkedList *list, int data) {
    LinkedListNode *node = LinkedListNode_new(data);
    node->prev = list->last;
    if (list->last != NULL) {
	list->last->next = node;
    }
    list->last = node;
    if (list->first == NULL) {
	list->first = node;
    }
}

//Union Set operation
//simply adds elements to set 1 that are contained uniquely in set2
inline void LinkedList_Union(LinkedList* s1, LinkedList* s2){
  for (LinkedListNode *node=s2->first; node != NULL; node=node->next){
    if (LinkedList_contains(s1,node->data) == 0) {
      LinkedList_add_at_end(s1,node->data);
    }
  }
}

inline void LinkedList_print_list(LinkedList *list) {
    for (LinkedListNode *node=list->first; node != NULL; node=node->next) {
       printf("%d", node->data);
	     if (node->next != NULL) {
	        printf(" ");
	       }
       }
    printf("\n");
}



inline LinkedListIterator* LinkedList_iterator(const LinkedList* set){
  LinkedListIterator* iterator = (LinkedListIterator*)malloc(sizeof(LinkedListIterator));
  iterator->node = set->first;
  return iterator;
}

inline bool LinkedListIterator_has_next(const LinkedListIterator* iterator){
  return iterator != NULL && iterator->node != NULL;
}

inline int LinkedListIterator_next(LinkedListIterator* iterator){
  if (iterator == NULL || iterator->node == NULL){
    abort();
  } else {
    int value = iterator->node->data;
    iterator->node = iterator->node->next;
    return value;
  }
}

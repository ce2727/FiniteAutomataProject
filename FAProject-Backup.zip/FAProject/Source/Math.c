#include "Math.h"
int Math_power(int x, int n)
{
  int pile = x;
  for (int i = 1; i < n; i++)
  {
    pile *= x;
  }
  return pile;
}
